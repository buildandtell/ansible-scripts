<?php
/*
 * Local plugin enable/disable settings
 * Auto-generated through plugin/extension manager
 *
 * NOTE: Plugins will not be added to this file unless there is a need to override a default setting. Plugins are
 *       enabled by default, unless having a 'disabled' file in their plugin folder.
 */
